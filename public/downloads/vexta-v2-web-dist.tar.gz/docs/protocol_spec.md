# Vexta V2 MessagePack Wire Protocol Specification

This document defines the WebSocket framing specification used between `vexta-v2` clients and `vexta-bridge-v2` relay servers.

---

## 1. Frame Encoding

Vexta V2 uses **MessagePack Binary Framing** (`@msgpack/msgpack` on TypeScript client, `rmp-serde` on Rust server) over WebSocket `ArrayBuffer` channels.

* **Binary Header Overhead**: ~45 bytes (vs ~180 bytes in JSON text frames).
* **Fallback**: The server supports JSON text frames for dev/debugging environments.

---

## 2. Protocol Handshake Sequence

```
Client                                                   Server
  │                                                        │
  │ ══════════════ [1. WebSocket Connect] ═══════════════> │
  │                                                        │
  │ <═════ [2. AUTH_CHALLENGE (Nonce + Server Ed25519)] ══ │
  │                                                        │
  │ ══════ [3. AUTH_RESPONSE (Client Ed25519 Sig)] ══════> │
  │                                                        │
  │ <═════ [4. AUTH_SUCCESS + Stream Offline Queue] ══════ │
```

---

## 3. Frame Specification Matrix

### A. Authentication Frames

#### `AUTH_CHALLENGE` (Server -> Client)
```json
{
  "type": "AUTH_CHALLENGE",
  "nonce": "<32-byte hex string>",
  "server_public_key": "<Base64 Ed25519 Public Key>",
  "server_signature": "<Base64 Signature of Nonce>"
}
```

#### `AUTH_RESPONSE` (Client -> Server)
```json
{
  "type": "AUTH_RESPONSE",
  "username": "komradkat",
  "ed25519_pubkey": "<Base64 Ed25519 Public Key>",
  "nonce": "<32-byte hex string>",
  "signature": "<Base64 Ed25519 Signature of Nonce>",
  "hardware_hash": "<SHA-256 Hardware ID Hash>",
  "device_name": "Linux Desktop"
}
```

#### `AUTH_SUCCESS` (Server -> Client)
```json
{
  "type": "AUTH_SUCCESS",
  "username": "komradkat"
}
```

---

### B. Messaging Frames

#### `SEND_MESSAGE` (Client -> Server)
```json
{
  "type": "SEND_MESSAGE",
  "recipient": "alice",
  "ciphertext": "<Base64 Double Ratchet Ciphertext>",
  "is_group": false,
  "timestamp": 1722698200000
}
```

#### `BLIND_MESSAGE` (Server -> Client)
```json
{
  "type": "BLIND_MESSAGE",
  "id": 1722698200000123,
  "sender": "komradkat",
  "ciphertext": "<Base64 Double Ratchet Ciphertext>",
  "timestamp": 1722698200000,
  "is_group": false
}
```

---

### C. Vault & Recovery Frames

#### `UPDATE_VAULT` (Client -> Server)
```json
{
  "type": "UPDATE_VAULT",
  "vault_data": "<Base64 Argon2id Encrypted Vault Payload>"
}
```

#### `GET_VAULT` (Client -> Server)
```json
{
  "type": "GET_VAULT"
}
```

#### `VAULT_RESPONSE` (Server -> Client)
```json
{
  "type": "VAULT_RESPONSE",
  "vault_data": "<Base64 Argon2id Encrypted Vault Payload>"
}
```
