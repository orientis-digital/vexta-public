# Vexta V2 UI Inventory & Design System

This document outlines the visual structure, glassmorphism design system tokens, wallpaper themes, and screen layouts for **Vexta V2**.

---

## 1. Design Tokens & Styling System

* **Primary Background**: `#0B0F19` (Obsidian Dark)
* **Accent Highlights**: `#06B6D4` (Electric Cyan) & `#8B5CF6` (Cyber Violet)
* **Success / TOFU Shield**: `#10B981` (Emerald Green)
* **Glassmorphism Panels**:
  * `glass-panel`: `background: rgba(15, 23, 42, 0.65)`, `backdrop-filter: blur(16px)`
  * `glass-input`: `background: rgba(15, 23, 42, 0.8)`, `border: 1px solid rgba(255, 255, 255, 0.1)`

---

## 2. Screen & Modal Inventory

| Screen / Modal | Component | Description |
| :--- | :--- | :--- |
| **App Shell Layout** | [`AppLayout.tsx`](file:///home/komradkat/Documents/Repositories/vexta-v2/src/components/AppLayout.tsx) | Master grid containing Sidebar, main workspace, and modal overlays. |
| **Sidebar Navigation** | [`Sidebar.tsx`](file:///home/komradkat/Documents/Repositories/vexta-v2/src/components/Sidebar.tsx) | Channel list, unread badge counters, search input, TOFU shield status badge, and profile footer. |
| **Chat Timeline** | [`ChatView.tsx`](file:///home/komradkat/Documents/Repositories/vexta-v2/src/components/ChatView.tsx) | 60fps message viewport, wallpaper themes, disappearing message countdowns, and context menus. |
| **Chat Input** | [`ChatInput.tsx`](file:///home/komradkat/Documents/Repositories/vexta-v2/src/components/ChatInput.tsx) | E2EE payload sender, EXIF/GPS photo scrubber toggle, self-destruct timer selector, file dropzone. |
| **Friends Roster** | [`FriendsView.tsx`](file:///home/komradkat/Documents/Repositories/vexta-v2/src/components/FriendsView.tsx) | Contact list, add contact by username/fingerprint, and shareable QR code identity modal (`vexta://user/{fp}`). |
| **Crypto Inspector** | [`SecurityInspectorModal.tsx`](file:///home/komradkat/Documents/Repositories/vexta-v2/src/components/SecurityInspectorModal.tsx) | Live modal inspecting active X25519 ratchet state, SHA-256 fingerprints, TOFU certificates, and audit logs. |
| **Vault & Settings** | [`SettingsView.tsx`](file:///home/komradkat/Documents/Repositories/vexta-v2/src/components/SettingsView.tsx) | Encrypted `.vxvault` exports/imports, custom bridge URL configuration, and danger zone vault wipe. |
| **Auth Wizard** | [`AuthModal.tsx`](file:///home/komradkat/Documents/Repositories/vexta-v2/src/components/AuthModal.tsx) | Zero-Knowledge Argon2id master password vault unlock & 256-bit emergency recovery code backup wizard. |

---

## 3. Wallpaper Presets

1. **Purple Glow**: `bg-gradient-purple-glow`
2. **Deep Ocean**: `bg-gradient-deep-ocean`
3. **Forest Night**: `bg-gradient-forest-night`
4. **Sunset Rose**: `bg-gradient-sunset-rose`
5. **Cyber Dark**: `bg-gradient-cyber-dark`
