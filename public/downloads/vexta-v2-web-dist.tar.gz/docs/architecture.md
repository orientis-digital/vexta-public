# Vexta V2 Client Architecture & Cryptographic Deep-Dive

This document details the internal architecture, cryptographic protocols, state management, and native IPC design of the **Vexta V2** desktop and web client.

---

## 1. Core System Layering

```
┌────────────────────────────────────────────────────────────────────────┐
│                          Vexta V2 Frontend                             │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │                    React 19 UI Layer                             │  │
│  │  ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌───────────────┐  │  │
│  │  │ Sidebar    │ │ ChatView   │ │FriendsView │ │SecurityModal  │  │  │
│  │  └────────────┘ └────────────┘ └────────────┘ └───────────────┘  │  │
│  └────────────────────────────────┬─────────────────────────────────┘  │
│                                   │ React Context                      │
│  ┌────────────────────────────────▼─────────────────────────────────┐  │
│  │                    VextaContext Provider                         │  │
│  └───────┬────────────────────────┬─────────────────────────┬───────┘  │
│          │                        │                         │          │
│  ┌───────▼────────┐      ┌────────▼─────────┐      ┌─────────▼──────┐  │
│  │ Crypto Engine  │      │ Storage Service  │      │ Bridge Client  │  │
│  │ Signal X25519  │      │ Local Vault      │      │ MessagePack    │  │
│  │ Double Ratchet │      │ SQLite / Local   │      │ WSS Connection │  │
│  └───────┬────────┘      └──────────────────┘      └────────┬───────┘  │
└──────────┼──────────────────────────────────────────────────┼──────────┘
           │ Native IPC                                       │ MessagePack WSS
┌──────────▼──────────────────────────────────────────────────▼──────────┐
│                           Tauri 2.0 Rust Core                          │
│     Hardware ID Hash · Secure Nonce Generator · TOFU Verification      │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Cryptographic Architecture

Vexta V2 upgrades key management from heavy RSA-4096 to the **Signal Protocol (Curve25519)**:

### A. Key Types
1. **Identity Signing Keypair (Ed25519)**: 32-byte public key used for authenticating to the bridge server and signing prekey bundles.
2. **Identity Diffie-Hellman Keypair (X25519)**: 32-byte public key used for initial key exchange.
3. **Master Key (MK)**: 256-bit key derived via **Argon2id** (`time_cost=3, memory=64MB, parallelism=4`).
4. **Data Encryption Key (DEK)**: 256-bit AES key generated at signup. Encrypted under the MK; protects the private keys and local SQLite vault.

### B. Signal Double Ratchet Flow
Every direct message undergoes a double ratchet step:
1. **DH Ratchet**: An ephemeral X25519 keypair is generated per message.
2. **KDF Chain**: The shared secret ($DH$) is passed through **HKDF-SHA256** to derive a 32-byte Message Key and 12-byte IV.
3. **AES-256-GCM Encryption**: The plaintext is encrypted with the Message Key and IV.
4. **Perfect Forward Secrecy**: Once a message key is used, it is erased from memory. Compromising the device's current state cannot decrypt past recorded ciphertexts.

---

## 3. Privacy & Media Scrubbing Engine

Before uploading image attachments (`.png`, `.jpg`, `.jpeg`, `.webp`), `VextaCryptoEngine.scrubFileMetadata()` strips EXIF/GPS tags by rendering the image onto an offscreen HTML5 canvas and re-exporting the raw pixel data to a clean Blob.

---

## 4. Disappearing Message Scheduler

Disappearing timers operate per contact or group:
* Timers can be set to 10s, 1m, 1h, or 1d.
* Each message stores an `expiresAt` timestamp.
* A background interval scheduler checks `StorageService.purgeExpiredMessages()` every 5 seconds and purges expired entries from local storage.
