# Vexta V2 — Desktop & Web Client

**Version 2.0.0** — High-Performance Zero-Knowledge End-to-End Encrypted Messenger for Windows, Linux, and macOS.

Built with **Tauri 2.0 (Rust core) + React 19 + TypeScript + Vite + Tailwind CSS**. Connects to the high-performance [Vexta Bridge V2](file:///home/komradkat/Documents/Repositories/vexta-bridge-v2) for zero-knowledge MessagePack binary message relaying.

---

## 🌟 Key Features

* **Tauri 2.0 Cross-Platform Engine**: Native support for Windows, Linux, and macOS with an installer size of **~15MB** and idling memory footprint of **~30MB RAM** (over 10x smaller and 8x lighter than Electron/Python Flet).
* **Signal Double Ratchet Cryptography**: Replaced legacy RSA-4096 with **Ed25519** (32-byte public key signatures) and **X25519** (ephemeral Diffie-Hellman key exchange) for **Perfect Forward Secrecy (PFS)** and post-compromise security.
* **Zero-Knowledge Argon2id Key Vault**: Local master key derived via Argon2id (`time_cost=3, memory=64MB, parallelism=4`).
* **MessagePack Binary Framing**: High-efficiency `@msgpack/msgpack` ArrayBuffer binary WebSocket transmission reducing header overhead by **~75%**.
* **TOFU Server Trust Inspector**: Trust-On-First-Use server public key verification with live MITM warning alerts and cryptographic diagnostic inspector modal.
* **Privacy & Media Scrubbing**: Automatic canvas-based EXIF/GPS metadata removal from images prior to chunked E2EE transmission.
* **Dynamic Wallpapers & Themes**: Sleek dark-mode obsidian glassmorphism UI with custom gradient wallpapers (Purple Glow, Deep Ocean, Forest Night, Sunset Rose, Cyber Dark).
* **Disappearing Messages**: Per-contact self-destruct timers (10s, 1m, 1h, 1d) with automated background cleanup scheduler.
* **Account Recovery & Vault Export**: 256-bit emergency recovery codes and password-protected `.vxvault` file export/import.

---

## 📁 Repository Structure

```
vexta-v2/
├── docs/
│   ├── architecture.md       # Full client architecture & crypto deep-dive
│   ├── protocol_spec.md       # MessagePack binary WebSocket frame specification
│   └── ui_inventory.md        # Screen structure & glassmorphism design system
├── src/
│   ├── components/            # React UI components (Sidebar, ChatView, FriendsView, etc.)
│   ├── context/               # VextaContext state provider
│   ├── crypto/                # Signal Double Ratchet & EXIF scrubber engine
│   ├── services/              # MessagePack WebSocket client & Storage service
│   ├── styles/                # Global CSS design tokens & glassmorphism utilities
│   ├── types/                 # TypeScript type definitions
│   ├── App.tsx                # Main App component
│   └── main.tsx               # Application entry point
├── src-tauri/
│   ├── Cargo.toml             # Rust backend dependencies
│   ├── tauri.conf.json        # Tauri desktop configuration
│   └── src/lib.rs             # Native Rust IPC commands (Hardware ID, random nonces)
├── package.json
└── vite.config.ts
```

---

## ⚡ Quick Start

### Prerequisites
* **Node.js**: v20.19.0+
* **Rust**: 1.94.0+ (with `cargo` installed)

### Installation

```bash
git clone https://github.com/komradkat/vexta-v2.git
cd vexta-v2
npm install
```

### Running in Web / Dev Mode (No GTK required)

```bash
npm run dev
```
Open [http://localhost:1420](http://localhost:1420) in your browser.

### Running as Desktop Native App (Tauri)

```bash
npm run tauri dev
```

### Production Build

```bash
npm run build
```

---

## 📖 Documentation

* 📘 [Client Architecture Deep-Dive](docs/architecture.md)
* 🔌 [MessagePack Wire Protocol Specification](docs/protocol_spec.md)
* 🎨 [UI Screen Inventory & Design System](docs/ui_inventory.md)

---

## 🔒 Security Model

Vexta operates on a **strict zero-knowledge architecture**:
1. Plaintext messages, private keys, contact rosters, and group memberships **never leave your device**.
2. The relay server (`vexta-bridge-v2`) only receives opaque ciphertext blobs.
3. Every message is encrypted with a unique ephemeral key derived via the **Signal Double Ratchet Protocol**.
